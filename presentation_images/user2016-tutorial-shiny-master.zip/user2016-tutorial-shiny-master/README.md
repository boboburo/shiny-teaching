# Effective Shiny Programming

## useR 2016 at Stanford University

Joe Cheng <joe@rstudio.com>  
June 27, 2016

View the [slides](https://cdn.rawgit.com/jcheng5/user2016-tutorial-shiny/master/slides.html)
